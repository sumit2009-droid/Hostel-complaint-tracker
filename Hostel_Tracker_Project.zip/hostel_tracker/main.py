"""
main.py  --  Hostel Complaint and Maintenance Tracker
Course: Computational Thinking and Programming (2026CSAE100)

Team lead / integration: Sumit Mittal
Run with:   python main.py
"""
import data_manager as dm
import priority as pr
import analysis as an
import validation as val
from datetime import date

MENU = """
========== HOSTEL COMPLAINT & MAINTENANCE TRACKER ==========
 1. Register a new complaint
 2. View all complaints (optional filter by block / status)
 3. View open complaints ranked by priority
 4. Update complaint status
 5. Detect repeated issues
 6. Show summary report
 7. Export report to report.txt
 0. Exit
=============================================================="""


def register(complaints):
    print("\n--- Register Complaint ---")
    room = val.get_room()
    category = val.get_category(pr.SEVERITY)
    description = val.get_description()
    filed_on = val.get_date("Date of complaint")
    c = dm.add_complaint(complaints, room, category, description, filed_on)
    if dm.save_complaints(complaints):
        print(f"\n  Complaint saved with ID {c['id']}  "
              f"(priority score {pr.priority_score(c)}).")


def view_all(complaints):
    print("\n--- All Complaints ---")
    block = status = None
    if val.get_yes_no("Filter by block?"):
        while True:
            block = input("Block letter (A-D): ").strip().upper()
            if block in ("A", "B", "C", "D"):
                break
            print("  [!] Enter A, B, C or D.")
    if val.get_yes_no("Filter by status?"):
        names = dm.STATUSES
        for i, s in enumerate(names, 1):
            print(f"   {i}. {s}")
        while True:
            pick = input("Choose status number: ").strip()
            if pick in ("1", "2", "3"):
                status = names[int(pick) - 1]
                break
            print("  [!] Enter 1, 2 or 3.")
    print()
    dm.print_table(dm.filter_complaints(complaints, block, status))


def view_ranked(complaints):
    print("\n--- Open Complaints Ranked by Priority ---")
    ranked = pr.rank_complaints(complaints)
    if not ranked:
        print("  No open complaints. Great!")
        return
    print(f"{'Rank':<5}{'Score':<7}{'Level':<10}{'ID':<6}{'Room':<8}"
          f"{'Category':<13}{'Days':<6}{'Status':<13}Description")
    print("-" * 95)
    for rank, (score, c) in enumerate(ranked, 1):
        print(f"{rank:<5}{score:<7}{pr.priority_label(score):<10}{c['id']:<6}"
              f"{c['room']:<8}{c['category']:<13}{pr.days_pending(c):<6}"
              f"{c['status']:<13}{c['description']}")


def update(complaints):
    print("\n--- Update Status ---")
    cid = val.get_complaint_id()
    c = dm.find_by_id(complaints, cid)
    if c is None:
        print(f"  [!] No complaint found with ID {cid}.")
        return
    print(f"  Current: {c['room']} | {c['category']} | {c['status']} | {c['description']}")
    for i, s in enumerate(dm.STATUSES, 1):
        print(f"   {i}. {s}")
    while True:
        pick = input("Choose new status number: ").strip()
        if pick in ("1", "2", "3"):
            break
        print("  [!] Enter 1, 2 or 3.")
    ok, message = dm.update_status(c, dm.STATUSES[int(pick) - 1])
    print(("  " if ok else "  [!] ") + message)
    if ok:
        dm.save_complaints(complaints)


def repeated(complaints):
    print("\n--- Repeated Issues ---")
    rooms, blocks = an.find_repeated_issues(complaints)
    if not rooms and not blocks:
        print("  No repeated issues found.")
        return
    for (room, cat), n, ids in rooms:
        print(f"  ROOM  {room}: '{cat}' reported {n} times ({', '.join(ids)})"
              "  -> inspect room for a permanent fix")
    for (block, cat), n, ids in blocks:
        print(f"  BLOCK {block}: '{cat}' reported {n} times ({', '.join(ids)})"
              "  -> possible block-wide fault")


def main():
    complaints = dm.load_complaints()
    print(f"Loaded {len(complaints)} complaint(s) from {dm.CSV_FILE}.")
    actions = {"1": register, "2": view_all, "3": view_ranked,
               "4": update, "5": repeated}
    while True:
        print(MENU)
        choice = val.get_menu_choice(["0", "1", "2", "3", "4", "5", "6", "7"])
        if choice == "0":
            print("Goodbye!")
            break
        elif choice in actions:
            actions[choice](complaints)
        elif choice == "6":
            print("\n" + an.build_report(complaints))
        elif choice == "7":
            if an.export_report(an.build_report(complaints)):
                print("  Report saved to report.txt")


if __name__ == "__main__":
    try:
        main()
    except (KeyboardInterrupt, EOFError):
        print("\nProgram closed.")
