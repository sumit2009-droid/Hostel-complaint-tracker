"""
data_manager.py  --  Complaint data module  (Bhavya Aggarwal)

Handles reading / writing the CSV file, adding complaints, and updating
status. A complaint is stored as a dictionary:
    {"id", "room", "category", "description", "date", "status", "resolved_date"}
"""
import csv
import os
from datetime import date
from validation import parse_date, DATE_FORMAT

CSV_FILE = "complaints.csv"
FIELDS = ["id", "room", "category", "description", "date", "status", "resolved_date"]
STATUSES = ("Pending", "In Progress", "Resolved")


def load_complaints(filename=CSV_FILE):
    """Read all complaints from the CSV. Missing file -> empty list.
    Malformed rows are skipped with a warning instead of crashing."""
    complaints = []
    if not os.path.exists(filename):
        return complaints
    try:
        with open(filename, newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for line_no, row in enumerate(reader, start=2):
                try:
                    filed = parse_date(row["date"])
                    if filed is None or row["status"] not in STATUSES:
                        raise ValueError("bad date or status")
                    resolved = parse_date(row["resolved_date"]) if row["resolved_date"] else None
                    complaints.append({
                        "id": row["id"], "room": row["room"],
                        "category": row["category"],
                        "description": row["description"],
                        "date": filed, "status": row["status"],
                        "resolved_date": resolved,
                    })
                except (KeyError, ValueError, TypeError, AttributeError):
                    print(f"  [!] Skipped malformed record at line {line_no}.")
    except OSError as error:
        print("  [!] Could not read file:", error)
    return complaints


def save_complaints(complaints, filename=CSV_FILE):
    """Write all complaints back to the CSV file."""
    try:
        with open(filename, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=FIELDS)
            writer.writeheader()
            for c in complaints:
                row = dict(c)
                row["date"] = c["date"].strftime(DATE_FORMAT)
                row["resolved_date"] = (c["resolved_date"].strftime(DATE_FORMAT)
                                        if c["resolved_date"] else "")
                writer.writerow(row)
        return True
    except OSError as error:
        print("  [!] Could not save file:", error)
        return False


def next_id(complaints):
    """Generate the next ID: C001, C002, ... (one more than the highest used)."""
    highest = 0
    for c in complaints:
        digits = c["id"][1:]
        if digits.isdigit():
            highest = max(highest, int(digits))
    return f"C{highest + 1:03d}"


def add_complaint(complaints, room, category, description, filed_on):
    """Create a new Pending complaint, add it to the list and return it."""
    complaint = {
        "id": next_id(complaints), "room": room, "category": category,
        "description": description, "date": filed_on,
        "status": "Pending", "resolved_date": None,
    }
    complaints.append(complaint)
    return complaint


def find_by_id(complaints, complaint_id):
    for c in complaints:
        if c["id"] == complaint_id:
            return c
    return None


def update_status(complaint, new_status, today=None):
    """
    Change status. Returns (True, message) or (False, reason).
    Rules: resolved complaints are final; resolution date is recorded.
    """
    today = today or date.today()
    if new_status not in STATUSES:
        return False, "Unknown status."
    if complaint["status"] == "Resolved":
        return False, "This complaint is already Resolved and cannot be changed."
    if new_status == complaint["status"]:
        return False, f"Complaint is already {new_status}."
    if new_status == "Resolved":
        if today < complaint["date"]:
            return False, "Resolution date cannot be before the complaint date."
        complaint["resolved_date"] = today
    complaint["status"] = new_status
    return True, f"{complaint['id']} updated to {new_status}."


def filter_complaints(complaints, block=None, status=None):
    """Return complaints matching an optional block letter and/or status."""
    result = []
    for c in complaints:
        if block and not c["room"].startswith(block):
            continue
        if status and c["status"] != status:
            continue
        result.append(c)
    return result


def print_table(rows):
    """Print complaints as a neat table."""
    if not rows:
        print("  (no complaints to show)")
        return
    header = f"{'ID':<6}{'Room':<8}{'Category':<13}{'Date':<12}{'Status':<13}Description"
    print(header)
    print("-" * 80)
    for c in rows:
        print(f"{c['id']:<6}{c['room']:<8}{c['category']:<13}"
              f"{c['date'].strftime(DATE_FORMAT):<12}{c['status']:<13}{c['description']}")
