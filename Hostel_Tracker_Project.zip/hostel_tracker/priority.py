"""
priority.py  --  Priority scoring and ranking module  (Gagan Sharma)

COMPUTATIONAL FEATURE:
    priority score = (severity of category x 10) + (days pending x 2)

* Severity (1-5) reflects how dangerous / disruptive the problem is.
* Days pending makes older complaints climb the list, so a minor
  problem cannot be ignored forever (this prevents "starvation").
"""
from datetime import date

# Category -> severity weight (1 = minor, 5 = critical)
SEVERITY = {
    "Electrical": 5,      # shock / fire risk
    "Plumbing": 4,        # water leakage, blocked drains
    "Wi-Fi": 3,           # affects studies
    "Furniture": 2,
    "Cleanliness": 2,
    "Other": 1,
}

SEVERITY_WEIGHT = 10   # points per severity level
DAY_WEIGHT = 2         # points per day pending


def days_pending(complaint, today=None):
    """Days since the complaint was filed (0 for a complaint filed today)."""
    today = today or date.today()
    return max((today - complaint["date"]).days, 0)


def priority_score(complaint, today=None):
    """Score of an open complaint. Resolved complaints score 0."""
    if complaint["status"] == "Resolved":
        return 0
    severity = SEVERITY.get(complaint["category"], 1)
    return severity * SEVERITY_WEIGHT + days_pending(complaint, today) * DAY_WEIGHT


def priority_label(score):
    """Turn a numeric score into a simple rule-based label."""
    if score >= 80:
        return "CRITICAL"
    if score >= 50:
        return "HIGH"
    if score >= 30:
        return "MEDIUM"
    return "LOW"


def rank_complaints(complaints, today=None):
    """
    Return a list of (score, complaint) for all open complaints,
    sorted from highest to lowest score. Ties: older complaint first.
    """
    open_items = [c for c in complaints if c["status"] != "Resolved"]
    scored = [(priority_score(c, today), c) for c in open_items]
    scored.sort(key=lambda pair: (-pair[0], pair[1]["date"], pair[1]["id"]))
    return scored
