"""
test_project.py  --  Automated tests  (Aarav Gupta)
Run with:   python test_project.py
"""
import unittest, os, tempfile
from datetime import date
import data_manager as dm
import priority as pr
import analysis as an
import validation as val

TODAY = date(2026, 11, 24)


def make(cid, room, cat, filed, status="Pending", resolved=None):
    return {"id": cid, "room": room, "category": cat, "description": "test issue",
            "date": filed, "status": status, "resolved_date": resolved}


class TestPriority(unittest.TestCase):
    def test_score_formula(self):                      # normal
        c = make("C001", "A-101", "Plumbing", date(2026, 11, 14))   # 10 days
        self.assertEqual(pr.priority_score(c, TODAY), 4 * 10 + 10 * 2)

    def test_filed_today_boundary(self):               # boundary
        c = make("C001", "A-101", "Electrical", TODAY)
        self.assertEqual(pr.priority_score(c, TODAY), 50)

    def test_resolved_scores_zero(self):
        c = make("C001", "A-101", "Electrical", date(2026, 11, 1), "Resolved", TODAY)
        self.assertEqual(pr.priority_score(c, TODAY), 0)

    def test_ranking_order_and_aging(self):
        old_minor = make("C001", "B-101", "Furniture", date(2026, 10, 1))   # 20+54*2=128
        new_critical = make("C002", "B-102", "Electrical", TODAY)           # 50
        ranked = pr.rank_complaints([new_critical, old_minor], TODAY)
        self.assertEqual(ranked[0][1]["id"], "C001")

    def test_ranking_excludes_resolved(self):
        r = make("C001", "A-101", "Plumbing", date(2026, 11, 1), "Resolved", TODAY)
        self.assertEqual(pr.rank_complaints([r], TODAY), [])


class TestData(unittest.TestCase):
    def test_add_and_next_id(self):
        lst = []
        c = dm.add_complaint(lst, "A-101", "Wi-Fi", "router down", TODAY)
        self.assertEqual(c["id"], "C001")
        self.assertEqual(dm.next_id(lst), "C002")

    def test_status_update_records_date(self):
        c = make("C001", "A-101", "Wi-Fi", date(2026, 11, 20))
        ok, _ = dm.update_status(c, "Resolved", TODAY)
        self.assertTrue(ok)
        self.assertEqual(c["resolved_date"], TODAY)

    def test_resolved_cannot_change(self):
        c = make("C001", "A-101", "Wi-Fi", date(2026, 11, 20), "Resolved", TODAY)
        ok, _ = dm.update_status(c, "Pending", TODAY)
        self.assertFalse(ok)

    def test_csv_round_trip(self):
        path = os.path.join(tempfile.mkdtemp(), "t.csv")
        lst = [make("C001", "A-101", "Wi-Fi", date(2026, 11, 20))]
        dm.save_complaints(lst, path)
        self.assertEqual(dm.load_complaints(path), lst)

    def test_missing_file_gives_empty_list(self):      # special case
        self.assertEqual(dm.load_complaints("no_such_file.csv"), [])

    def test_malformed_row_skipped(self):              # invalid data
        path = os.path.join(tempfile.mkdtemp(), "bad.csv")
        with open(path, "w") as f:
            f.write("id,room,category,description,date,status,resolved_date\n")
            f.write("C001,A-101,Wi-Fi,ok issue,2026-11-20,Pending,\n")
            f.write("C002,A-102,Wi-Fi,bad date,not-a-date,Pending,\n")
        self.assertEqual(len(dm.load_complaints(path)), 1)


class TestAnalysis(unittest.TestCase):
    def setUp(self):
        self.data = [
            make("C001", "A-101", "Plumbing", date(2026, 11, 1), "Resolved", date(2026, 11, 5)),
            make("C002", "A-101", "Plumbing", date(2026, 11, 10)),
            make("C003", "A-102", "Plumbing", date(2026, 11, 12)),
            make("C004", "B-201", "Wi-Fi", date(2026, 11, 12), "Resolved", date(2026, 11, 14)),
        ]

    def test_category_counts(self):
        self.assertEqual(an.count_by_category(self.data), {"Plumbing": 3, "Wi-Fi": 1})

    def test_average_resolution(self):
        self.assertEqual(an.average_resolution_days(self.data), 3.0)   # (4+2)/2

    def test_repeated_detection(self):
        rooms, blocks = an.find_repeated_issues(self.data)
        self.assertEqual(rooms[0][0], ("A-101", "Plumbing"))
        self.assertEqual(blocks[0][0], ("A", "Plumbing"))

    def test_empty_data_report(self):                  # special case
        self.assertIn("No complaints", an.build_report([], TODAY))
        self.assertIsNone(an.average_resolution_days([]))


class TestValidation(unittest.TestCase):
    def test_room_rules(self):
        self.assertTrue(val.is_valid_room("B-214"))
        for bad in ("Z-101", "A101", "A-10", "", "a-101"):
            self.assertFalse(val.is_valid_room(bad))

    def test_date_parsing(self):
        self.assertEqual(val.parse_date("2026-11-20"), date(2026, 11, 20))
        self.assertIsNone(val.parse_date("20-11-2026"))
        self.assertIsNone(val.parse_date("2026-02-30"))


if __name__ == "__main__":
    unittest.main(verbosity=2)
