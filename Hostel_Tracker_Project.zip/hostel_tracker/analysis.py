"""
analysis.py  --  Analysis and reports module  (Pankaj Kumar)

* Repeated-issue (pattern) detection
* Category-wise counts
* Average resolution time
* Text report + simple bar chart, exported to report.txt
"""
from datetime import date


def count_by_category(complaints):
    """Return {category: number_of_complaints} using a dictionary."""
    counts = {}
    for c in complaints:
        counts[c["category"]] = counts.get(c["category"], 0) + 1
    return counts


def count_by_status(complaints):
    counts = {"Pending": 0, "In Progress": 0, "Resolved": 0}
    for c in complaints:
        counts[c["status"]] += 1
    return counts


def average_resolution_days(complaints, category=None):
    """Average (resolved_date - date) in days; None if nothing is resolved."""
    days = [(c["resolved_date"] - c["date"]).days
            for c in complaints
            if c["status"] == "Resolved" and c["resolved_date"]
            and (category is None or c["category"] == category)]
    if not days:
        return None
    return sum(days) / len(days)


def find_repeated_issues(complaints, room_limit=2, block_limit=3):
    """
    Pattern identification.
      * Same ROOM + same category filed `room_limit`+ times  -> repeated room issue
      * Same BLOCK + same category filed `block_limit`+ times -> block-wide issue
    Returns two lists of (key, count, [ids]).
    """
    by_room, by_block = {}, {}
    for c in complaints:
        by_room.setdefault((c["room"], c["category"]), []).append(c["id"])
        by_block.setdefault((c["room"][0], c["category"]), []).append(c["id"])

    room_issues = [(k, len(v), v) for k, v in by_room.items() if len(v) >= room_limit]
    block_issues = [(k, len(v), v) for k, v in by_block.items() if len(v) >= block_limit]
    room_issues.sort(key=lambda x: -x[1])
    block_issues.sort(key=lambda x: -x[1])
    return room_issues, block_issues


def bar_chart(counts, width=30):
    """Simple text visualization: one row of # symbols per category."""
    if not counts:
        return "  (no data)"
    biggest = max(counts.values())
    lines = []
    for name, value in sorted(counts.items(), key=lambda kv: -kv[1]):
        bar = "#" * max(1, round(value / biggest * width))
        lines.append(f"  {name:<13}| {bar} {value}")
    return "\n".join(lines)


def build_report(complaints, today=None):
    """Return the full summary report as a string."""
    today = today or date.today()
    lines = ["=" * 56,
             "   HOSTEL MAINTENANCE SUMMARY REPORT",
             f"   Generated on: {today}",
             "=" * 56]
    if not complaints:
        lines.append("No complaints recorded yet.")
        return "\n".join(lines)

    status = count_by_status(complaints)
    lines.append(f"Total complaints : {len(complaints)}")
    for name, n in status.items():
        lines.append(f"  {name:<12}: {n}")

    lines.append("\nComplaints by category:")
    lines.append(bar_chart(count_by_category(complaints)))

    lines.append("\nAverage resolution time (days):")
    overall = average_resolution_days(complaints)
    if overall is None:
        lines.append("  No resolved complaints yet.")
    else:
        for cat in sorted(count_by_category(complaints)):
            avg = average_resolution_days(complaints, cat)
            if avg is not None:
                lines.append(f"  {cat:<13}: {avg:.1f}")
        lines.append(f"  {'Overall':<13}: {overall:.1f}")

    rooms, blocks = find_repeated_issues(complaints)
    lines.append("\nRepeated issues:")
    if not rooms and not blocks:
        lines.append("  None detected.")
    for (room, cat), n, ids in rooms:
        lines.append(f"  Room {room}: {cat} x{n}  ({', '.join(ids)})")
    for (block, cat), n, ids in blocks:
        lines.append(f"  Block {block}: {cat} x{n}  ({', '.join(ids)})")
    return "\n".join(lines)


def export_report(text, filename="report.txt"):
    try:
        with open(filename, "w", encoding="utf-8") as f:
            f.write(text + "\n")
        return True
    except OSError as error:
        print("  [!] Could not write report:", error)
        return False
