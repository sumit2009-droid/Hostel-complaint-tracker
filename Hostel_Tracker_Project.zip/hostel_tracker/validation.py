"""
validation.py  --  Input handling module  (Aarav Gupta)

Every function here keeps asking until the user gives a valid value, so the
rest of the program never receives bad data and never crashes on bad input.
"""
import re
from datetime import datetime, date

DATE_FORMAT = "%Y-%m-%d"
ROOM_PATTERN = re.compile(r"^[A-D]-\d{3}$")   # e.g. A-101 (blocks A to D)


def parse_date(text):
    """Convert 'YYYY-MM-DD' text to a date object. Returns None if invalid."""
    try:
        return datetime.strptime(text.strip(), DATE_FORMAT).date()
    except (ValueError, AttributeError):
        return None


def is_valid_room(room):
    """Room must look like A-101 (block letter A-D, dash, 3 digits)."""
    return bool(ROOM_PATTERN.match(room))


def get_menu_choice(valid_choices):
    """Ask for a menu option until it is one of valid_choices."""
    while True:
        choice = input("Enter your choice: ").strip()
        if choice in valid_choices:
            return choice
        print("  [!] Invalid option. Please choose from:", ", ".join(valid_choices))


def get_room():
    """Ask for a room number in the format A-101."""
    while True:
        room = input("Room number (e.g. A-101): ").strip().upper()
        if is_valid_room(room):
            return room
        print("  [!] Invalid room. Use block A-D, a dash and 3 digits, e.g. B-214.")


def get_description():
    """Description must be 5-100 characters; commas are replaced for CSV safety."""
    while True:
        text = input("Short description of the problem: ").strip()
        if 5 <= len(text) <= 100:
            return text.replace(",", ";")
        print("  [!] Description must be between 5 and 100 characters.")


def get_category(categories):
    """Show numbered categories and return the chosen category name."""
    names = list(categories)
    for number, name in enumerate(names, start=1):
        print(f"   {number}. {name}")
    while True:
        raw = input("Choose category number: ").strip()
        if raw.isdigit() and 1 <= int(raw) <= len(names):
            return names[int(raw) - 1]
        print(f"  [!] Enter a number between 1 and {len(names)}.")


def get_date(prompt, today=None):
    """Ask for a date (YYYY-MM-DD). Blank = today. Future dates are rejected."""
    today = today or date.today()
    while True:
        raw = input(f"{prompt} (YYYY-MM-DD, press Enter for today): ").strip()
        if raw == "":
            return today
        parsed = parse_date(raw)
        if parsed is None:
            print("  [!] Invalid date. Use the format YYYY-MM-DD, e.g. 2026-11-20.")
        elif parsed > today:
            print("  [!] Date cannot be in the future.")
        else:
            return parsed


def get_complaint_id():
    """Complaint ID looks like C001."""
    while True:
        cid = input("Complaint ID (e.g. C001): ").strip().upper()
        if re.match(r"^C\d{3,}$", cid):
            return cid
        print("  [!] Invalid ID format. Example: C007")


def get_yes_no(prompt):
    while True:
        answer = input(prompt + " (y/n): ").strip().lower()
        if answer in ("y", "n"):
            return answer == "y"
        print("  [!] Please type y or n.")
