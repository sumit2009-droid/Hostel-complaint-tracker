Hostel Complaint and Maintenance Tracker  (2026CSAE100)
Run:    python main.py          (Python 3.8+, no extra packages)
Test:   python test_project.py
Files:  main.py, data_manager.py, priority.py, analysis.py, validation.py,
        complaints.csv (sample data), Project_Report.docx, Project_Slides.pptx, screenshots/
